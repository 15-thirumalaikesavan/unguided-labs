const express = require('express');
// const path = require('path');
// const bodyParser = require('body-parser');
// const cors = require('cors');
// const passport = require('passport');
// const mongoose = require('mongoose');

//initialize the app
const app = express();

//configure route for index
app.get('/', (req, res) => {
  res.send('The index endpoint');
});

//configure port for express
const port = 3000;

//start the server
app.listen(port, () => {
  console.log(`Server started on port ${port}`);
});
