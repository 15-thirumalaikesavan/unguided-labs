const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const cors = require('cors');
const passport = require('passport');
const mongoose = require('mongoose');
const dbconfig = require('./config/database');
// Passport Config
require('./config/passport')(passport);

//connect to db
mongoose.connect(dbconfig.database);

//handling connected event emitted by EventEmitter
mongoose.connection.on('connected', () => {
  console.log('Connected to MongoDB : ' + dbconfig.database);
});

//handling error event emitted by EventEmitter
mongoose.connection.on('error', (error) => {
    console.log('Error connecting to MongoDB : ' + dbconfig.database + ' : ' + error);
});

//initialize the app
const app = express();

// Load routes
const users = require('./routes/users');

//configure port for express
const port = 3000;

// CORS Middleware
app.use(cors());

// Body-Parser Middleware
//   to access req.body and get the form value
app.use(bodyParser.json());


// Passport Middleware 
//   *MUST* be after Express Session Middleware
//   if express-session is being used
app.use(passport.initialize());
app.use(passport.session());


// Static Folder
app.use(express.static(path.join(__dirname, 'public')));

// Use routes
app.use('/users', users);

//configure route for index
app.get('/', (req, res) => {
  res.send('The index endpoint');
});

//start the server
app.listen(port, () => {
  console.log(`Server started on port ${port}`);
});
